package com.aeoncredit.aeonpay.core.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

/**
 * The persistent class for the consumer_accounts database table.
 * 
 */
@Entity
@Table(name="consumer_accounts")
@NamedQuery(name="ConsumerAccount.findAll", query="SELECT c FROM ConsumerAccount c")
public class ConsumerAccount implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ConsumerAccountPK id;

	@Column(name="consumer_account")
	private String consumerAccount;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="create_date")
	private Date createDate;

	@Column(name="create_user")
	private String createUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="delete_date")
	private Date deleteDate;

	@Column(name="delete_user")
	private String deleteUser;

	@Column(name="is_primary_account")
	private byte isPrimaryAccount;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="update_date")
	private Date updateDate;

	@Column(name="update_user")
	private String updateUser;

	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="user_id")
	private User user;

	public ConsumerAccount() {
	}

	public ConsumerAccountPK getId() {
		return this.id;
	}

	public void setId(ConsumerAccountPK id) {
		this.id = id;
	}

	public String getConsumerAccount() {
		return this.consumerAccount;
	}

	public void setConsumerAccount(String consumerAccount) {
		this.consumerAccount = consumerAccount;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getDeleteDate() {
		return this.deleteDate;
	}

	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}

	public String getDeleteUser() {
		return this.deleteUser;
	}

	public void setDeleteUser(String deleteUser) {
		this.deleteUser = deleteUser;
	}

	public byte getIsPrimaryAccount() {
		return this.isPrimaryAccount;
	}

	public void setIsPrimaryAccount(byte isPrimaryAccount) {
		this.isPrimaryAccount = isPrimaryAccount;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateUser() {
		return this.updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}