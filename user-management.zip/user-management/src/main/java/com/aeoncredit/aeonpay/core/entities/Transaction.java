package com.aeoncredit.aeonpay.core.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.math.BigInteger;


/**
 * The persistent class for the transactions database table.
 * 
 */
@Entity
@Table(name="transactions")
@NamedQuery(name="Transaction.findAll", query="SELECT t FROM Transaction t")
public class Transaction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="transaction_id")
	private String transactionId;

	@Column(name="approver_user_id")
	private int approverUserId;

	@Column(name="consumer_account")
	private String consumerAccount;

	@Column(name="consumer_name")
	private String consumerName;

	@Column(name="convenience_fee")
	private BigDecimal convenienceFee;

	@Column(name="convenience_fee_rate")
	private BigDecimal convenienceFeeRate;

	@Column(name="conversion_currency")
	private short conversionCurrency;

	@Column(name="conversion_rate")
	private BigDecimal conversionRate;

	@Column(name="converted_amount")
	private BigDecimal convertedAmount;

	@Column(name="device_serial_code")
	private String deviceSerialCode;

	@Column(name="merchant_account")
	private String merchantAccount;

	@Column(name="merchant_name")
	private String merchantName;

	@Column(name="originating_user_id")
	private int originatingUserId;

	@Column(name="parent_transaction_id")
	private BigInteger parentTransactionId;

	@Column(name="processing_status")
	private String processingStatus;

	@Column(name="reference_number")
	private String referenceNumber;

	@Column(name="system_audit_trace_number")
	private String systemAuditTraceNumber;

	@Column(name="transaction_amount")
	private BigDecimal transactionAmount;

	@Column(name="transaction_approval_code")
	private String transactionApprovalCode;

	@Column(name="transaction_currency")
	private short transactionCurrency;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="transaction_local_date")
	private Date transactionLocalDate;

	@Column(name="transaction_type")
	private String transactionType;

	@Column(name="transmission_time")
	private String transmissionTime;

	public Transaction() {
	}

	public String getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public int getApproverUserId() {
		return this.approverUserId;
	}

	public void setApproverUserId(int approverUserId) {
		this.approverUserId = approverUserId;
	}

	public String getConsumerAccount() {
		return this.consumerAccount;
	}

	public void setConsumerAccount(String consumerAccount) {
		this.consumerAccount = consumerAccount;
	}

	public String getConsumerName() {
		return this.consumerName;
	}

	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}

	public BigDecimal getConvenienceFee() {
		return this.convenienceFee;
	}

	public void setConvenienceFee(BigDecimal convenienceFee) {
		this.convenienceFee = convenienceFee;
	}

	public BigDecimal getConvenienceFeeRate() {
		return this.convenienceFeeRate;
	}

	public void setConvenienceFeeRate(BigDecimal convenienceFeeRate) {
		this.convenienceFeeRate = convenienceFeeRate;
	}

	public short getConversionCurrency() {
		return this.conversionCurrency;
	}

	public void setConversionCurrency(short conversionCurrency) {
		this.conversionCurrency = conversionCurrency;
	}

	public BigDecimal getConversionRate() {
		return this.conversionRate;
	}

	public void setConversionRate(BigDecimal conversionRate) {
		this.conversionRate = conversionRate;
	}

	public BigDecimal getConvertedAmount() {
		return this.convertedAmount;
	}

	public void setConvertedAmount(BigDecimal convertedAmount) {
		this.convertedAmount = convertedAmount;
	}

	public String getDeviceSerialCode() {
		return this.deviceSerialCode;
	}

	public void setDeviceSerialCode(String deviceSerialCode) {
		this.deviceSerialCode = deviceSerialCode;
	}

	public String getMerchantAccount() {
		return this.merchantAccount;
	}

	public void setMerchantAccount(String merchantAccount) {
		this.merchantAccount = merchantAccount;
	}

	public String getMerchantName() {
		return this.merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public int getOriginatingUserId() {
		return this.originatingUserId;
	}

	public void setOriginatingUserId(int originatingUserId) {
		this.originatingUserId = originatingUserId;
	}

	public BigInteger getParentTransactionId() {
		return this.parentTransactionId;
	}

	public void setParentTransactionId(BigInteger parentTransactionId) {
		this.parentTransactionId = parentTransactionId;
	}

	public String getProcessingStatus() {
		return this.processingStatus;
	}

	public void setProcessingStatus(String processingStatus) {
		this.processingStatus = processingStatus;
	}

	public String getReferenceNumber() {
		return this.referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public String getSystemAuditTraceNumber() {
		return this.systemAuditTraceNumber;
	}

	public void setSystemAuditTraceNumber(String systemAuditTraceNumber) {
		this.systemAuditTraceNumber = systemAuditTraceNumber;
	}

	public BigDecimal getTransactionAmount() {
		return this.transactionAmount;
	}

	public void setTransactionAmount(BigDecimal transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getTransactionApprovalCode() {
		return this.transactionApprovalCode;
	}

	public void setTransactionApprovalCode(String transactionApprovalCode) {
		this.transactionApprovalCode = transactionApprovalCode;
	}

	public short getTransactionCurrency() {
		return this.transactionCurrency;
	}

	public void setTransactionCurrency(short transactionCurrency) {
		this.transactionCurrency = transactionCurrency;
	}

	public Date getTransactionLocalDate() {
		return this.transactionLocalDate;
	}

	public void setTransactionLocalDate(Date transactionLocalDate) {
		this.transactionLocalDate = transactionLocalDate;
	}

	public String getTransactionType() {
		return this.transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransmissionTime() {
		return this.transmissionTime;
	}

	public void setTransmissionTime(String transmissionTime) {
		this.transmissionTime = transmissionTime;
	}

}