package com.aeoncredit.aeonpay.core.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the permissions database table.
 * 
 */
@Entity
@Table(name="permissions")
@NamedQuery(name="Permission.findAll", query="SELECT p FROM Permission p")
public class Permission implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="permission_id")
	private byte permissionId;

	@Column(name="can_approve")
	private byte canApprove;

	@Column(name="can_create")
	private byte canCreate;

	@Column(name="can_delete")
	private byte canDelete;

	@Column(name="can_download")
	private byte canDownload;

	@Column(name="can_logical_delete")
	private byte canLogicalDelete;

	@Column(name="can_read")
	private byte canRead;

	@Column(name="can_update")
	private byte canUpdate;

	@Column(name="can_upload")
	private byte canUpload;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="create_date")
	private Date createDate;

	@Column(name="create_user")
	private String createUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="delete_date")
	private Date deleteDate;

	@Column(name="delete_user")
	private String deleteUser;

	private String permission;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="update_date")
	private Date updateDate;

	@Column(name="update_user")
	private String updateUser;

	//bi-directional many-to-one association to RolePermission
	@OneToMany(mappedBy="permission")
	private List<RolePermission> rolePermissions;

	public Permission() {
	}

	public byte getPermissionId() {
		return this.permissionId;
	}

	public void setPermissionId(byte permissionId) {
		this.permissionId = permissionId;
	}

	public byte getCanApprove() {
		return this.canApprove;
	}

	public void setCanApprove(byte canApprove) {
		this.canApprove = canApprove;
	}

	public byte getCanCreate() {
		return this.canCreate;
	}

	public void setCanCreate(byte canCreate) {
		this.canCreate = canCreate;
	}

	public byte getCanDelete() {
		return this.canDelete;
	}

	public void setCanDelete(byte canDelete) {
		this.canDelete = canDelete;
	}

	public byte getCanDownload() {
		return this.canDownload;
	}

	public void setCanDownload(byte canDownload) {
		this.canDownload = canDownload;
	}

	public byte getCanLogicalDelete() {
		return this.canLogicalDelete;
	}

	public void setCanLogicalDelete(byte canLogicalDelete) {
		this.canLogicalDelete = canLogicalDelete;
	}

	public byte getCanRead() {
		return this.canRead;
	}

	public void setCanRead(byte canRead) {
		this.canRead = canRead;
	}

	public byte getCanUpdate() {
		return this.canUpdate;
	}

	public void setCanUpdate(byte canUpdate) {
		this.canUpdate = canUpdate;
	}

	public byte getCanUpload() {
		return this.canUpload;
	}

	public void setCanUpload(byte canUpload) {
		this.canUpload = canUpload;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getDeleteDate() {
		return this.deleteDate;
	}

	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}

	public String getDeleteUser() {
		return this.deleteUser;
	}

	public void setDeleteUser(String deleteUser) {
		this.deleteUser = deleteUser;
	}

	public String getPermission() {
		return this.permission;
	}

	public void setPermission(String permission) {
		this.permission = permission;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateUser() {
		return this.updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public List<RolePermission> getRolePermissions() {
		return this.rolePermissions;
	}

	public void setRolePermissions(List<RolePermission> rolePermissions) {
		this.rolePermissions = rolePermissions;
	}

	public RolePermission addRolePermission(RolePermission rolePermission) {
		getRolePermissions().add(rolePermission);
		rolePermission.setPermission(this);

		return rolePermission;
	}

	public RolePermission removeRolePermission(RolePermission rolePermission) {
		getRolePermissions().remove(rolePermission);
		rolePermission.setPermission(null);

		return rolePermission;
	}

}