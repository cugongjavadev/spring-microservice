package com.aeoncredit.aeonpay.core.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the user_credentials database table.
 * 
 */
@Embeddable
public class UserCredentialPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="user_id", insertable=false, updatable=false)
	private int userId;

	@Column(name="credential_id", insertable=false, updatable=false)
	private byte credentialId;

	private byte ordinal;

	public UserCredentialPK() {
	}
	public int getUserId() {
		return this.userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public byte getCredentialId() {
		return this.credentialId;
	}
	public void setCredentialId(byte credentialId) {
		this.credentialId = credentialId;
	}
	public byte getOrdinal() {
		return this.ordinal;
	}
	public void setOrdinal(byte ordinal) {
		this.ordinal = ordinal;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof UserCredentialPK)) {
			return false;
		}
		UserCredentialPK castOther = (UserCredentialPK)other;
		return 
			(this.userId == castOther.userId)
			&& (this.credentialId == castOther.credentialId)
			&& (this.ordinal == castOther.ordinal);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.userId;
		hash = hash * prime + ((int) this.credentialId);
		hash = hash * prime + ((int) this.ordinal);
		
		return hash;
	}
}