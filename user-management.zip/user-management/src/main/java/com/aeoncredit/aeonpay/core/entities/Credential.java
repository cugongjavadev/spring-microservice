package com.aeoncredit.aeonpay.core.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the credentials database table.
 * 
 */
@Entity
@Table(name="credentials")
@NamedQuery(name="Credential.findAll", query="SELECT c FROM Credential c")
public class Credential implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="credential_id")
	private byte credentialId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="create_date")
	private Date createDate;

	@Column(name="create_user")
	private String createUser;

	private String credential;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="delete_date")
	private Date deleteDate;

	@Column(name="delete_user")
	private String deleteUser;

	//bi-directional many-to-one association to UserCredential
	@OneToMany(mappedBy="credential")
	private List<UserCredential> userCredentials;

	public Credential() {
	}

	public byte getCredentialId() {
		return this.credentialId;
	}

	public void setCredentialId(byte credentialId) {
		this.credentialId = credentialId;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getCredential() {
		return this.credential;
	}

	public void setCredential(String credential) {
		this.credential = credential;
	}

	public Date getDeleteDate() {
		return this.deleteDate;
	}

	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}

	public String getDeleteUser() {
		return this.deleteUser;
	}

	public void setDeleteUser(String deleteUser) {
		this.deleteUser = deleteUser;
	}

	public List<UserCredential> getUserCredentials() {
		return this.userCredentials;
	}

	public void setUserCredentials(List<UserCredential> userCredentials) {
		this.userCredentials = userCredentials;
	}

	public UserCredential addUserCredential(UserCredential userCredential) {
		getUserCredentials().add(userCredential);
		userCredential.setCredential(this);

		return userCredential;
	}

	public UserCredential removeUserCredential(UserCredential userCredential) {
		getUserCredentials().remove(userCredential);
		userCredential.setCredential(null);

		return userCredential;
	}

}