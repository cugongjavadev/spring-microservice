package com.aeoncredit.aeonpay.core.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the merchant_profiles database table.
 * 
 */
@Entity
@Table(name="merchant_profiles")
@NamedQuery(name="MerchantProfile.findAll", query="SELECT m FROM MerchantProfile m")
public class MerchantProfile implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="merchant_id")
	private int merchantId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="create_date")
	private Date createDate;

	@Column(name="create_user")
	private String createUser;

	@Column(name="merchant_name")
	private String merchantName;

	@Column(name="parent_merchant_id")
	private int parentMerchantId;

	@Column(name="send_edc_pos_notification")
	private byte sendEdcPosNotification;

	@Column(name="send_push_notification")
	private byte sendPushNotification;

	@Column(name="send_sms_notification")
	private byte sendSmsNotification;

	@Column(name="send_web_notification")
	private byte sendWebNotification;

	@Column(name="trading_name")
	private String tradingName;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="update_date")
	private Date updateDate;

	@Column(name="update_user")
	private String updateUser;

	//bi-directional many-to-one association to MerchantAccount
	@OneToMany(mappedBy="merchantProfile")
	private List<MerchantAccount> merchantAccounts;

	//bi-directional many-to-one association to MerchantApplication
	@ManyToOne
	@JoinColumn(name="application_id")
	private MerchantApplication merchantApplication;

	//bi-directional many-to-one association to MerchantUser
	@OneToMany(mappedBy="merchantProfile")
	private List<MerchantUser> merchantUsers;

	public MerchantProfile() {
	}

	public int getMerchantId() {
		return this.merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getMerchantName() {
		return this.merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public int getParentMerchantId() {
		return this.parentMerchantId;
	}

	public void setParentMerchantId(int parentMerchantId) {
		this.parentMerchantId = parentMerchantId;
	}

	public byte getSendEdcPosNotification() {
		return this.sendEdcPosNotification;
	}

	public void setSendEdcPosNotification(byte sendEdcPosNotification) {
		this.sendEdcPosNotification = sendEdcPosNotification;
	}

	public byte getSendPushNotification() {
		return this.sendPushNotification;
	}

	public void setSendPushNotification(byte sendPushNotification) {
		this.sendPushNotification = sendPushNotification;
	}

	public byte getSendSmsNotification() {
		return this.sendSmsNotification;
	}

	public void setSendSmsNotification(byte sendSmsNotification) {
		this.sendSmsNotification = sendSmsNotification;
	}

	public byte getSendWebNotification() {
		return this.sendWebNotification;
	}

	public void setSendWebNotification(byte sendWebNotification) {
		this.sendWebNotification = sendWebNotification;
	}

	public String getTradingName() {
		return this.tradingName;
	}

	public void setTradingName(String tradingName) {
		this.tradingName = tradingName;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateUser() {
		return this.updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public List<MerchantAccount> getMerchantAccounts() {
		return this.merchantAccounts;
	}

	public void setMerchantAccounts(List<MerchantAccount> merchantAccounts) {
		this.merchantAccounts = merchantAccounts;
	}

	public MerchantAccount addMerchantAccount(MerchantAccount merchantAccount) {
		getMerchantAccounts().add(merchantAccount);
		merchantAccount.setMerchantProfile(this);

		return merchantAccount;
	}

	public MerchantAccount removeMerchantAccount(MerchantAccount merchantAccount) {
		getMerchantAccounts().remove(merchantAccount);
		merchantAccount.setMerchantProfile(null);

		return merchantAccount;
	}

	public MerchantApplication getMerchantApplication() {
		return this.merchantApplication;
	}

	public void setMerchantApplication(MerchantApplication merchantApplication) {
		this.merchantApplication = merchantApplication;
	}

	public List<MerchantUser> getMerchantUsers() {
		return this.merchantUsers;
	}

	public void setMerchantUsers(List<MerchantUser> merchantUsers) {
		this.merchantUsers = merchantUsers;
	}

	public MerchantUser addMerchantUser(MerchantUser merchantUser) {
		getMerchantUsers().add(merchantUser);
		merchantUser.setMerchantProfile(this);

		return merchantUser;
	}

	public MerchantUser removeMerchantUser(MerchantUser merchantUser) {
		getMerchantUsers().remove(merchantUser);
		merchantUser.setMerchantProfile(null);

		return merchantUser;
	}

}