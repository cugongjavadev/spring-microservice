package com.aeoncredit.aeonpay.account.command;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.commandhandling.model.Aggregate;
import org.axonframework.commandhandling.model.AggregateNotFoundException;
import org.axonframework.commandhandling.model.Repository;
import org.axonframework.eventhandling.EventBus;

import static org.axonframework.eventhandling.GenericEventMessage.asEventMessage;

public class UserAccountCommandHandler {

    private Repository<UserAccount> repository;
    private EventBus eventBus;

    public UserAccountCommandHandler(Repository<UserAccount> repository, EventBus eventBus) {
        this.repository = repository;
        this.eventBus = eventBus;
    }

    @CommandHandler
    public void handle(NewUserAccountCommand command) {
        try {
            Aggregate<UserAccount> userAccountAggregate = repository.load(command.getUserId());
            userAccountAggregate.execute(userAccount -> userAccount
                    .addUser(command.getUserId()));
            
            
        } catch (AggregateNotFoundException exception) {
            //eventBus.publish(asEventMessage(new SourceBankAccountNotFoundEvent(command.getBankTransferId())));
        }
    }

    @CommandHandler
    public void handle(RemoveUserAccountCommand command) {
        try {
            Aggregate<UserAccount> userAccountAggregate = repository.load(command.getUserId());
            userAccountAggregate.execute(userAccount -> userAccount
                    .deleteUser(command.getUserId()));
        }
        catch (AggregateNotFoundException exception) {
            //eventBus.publish(asEventMessage(new DestinationBankAccountNotFoundEvent(command.getBankTransferId())));
        }
    }
}
