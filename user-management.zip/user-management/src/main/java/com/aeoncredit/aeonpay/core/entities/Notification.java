package com.aeoncredit.aeonpay.core.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the notifications database table.
 * 
 */
@Entity
@Table(name="notifications")
@NamedQuery(name="Notification.findAll", query="SELECT n FROM Notification n")
public class Notification implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="notification_id")
	private String notificationId;

	@Column(name="is_read")
	private byte isRead;

	private String message;

	@Column(name="message_subject")
	private String messageSubject;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="notification_date")
	private Date notificationDate;

	@Column(name="recipient_user_id")
	private int recipientUserId;

	public Notification() {
	}

	public String getNotificationId() {
		return this.notificationId;
	}

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public byte getIsRead() {
		return this.isRead;
	}

	public void setIsRead(byte isRead) {
		this.isRead = isRead;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessageSubject() {
		return this.messageSubject;
	}

	public void setMessageSubject(String messageSubject) {
		this.messageSubject = messageSubject;
	}

	public Date getNotificationDate() {
		return this.notificationDate;
	}

	public void setNotificationDate(Date notificationDate) {
		this.notificationDate = notificationDate;
	}

	public int getRecipientUserId() {
		return this.recipientUserId;
	}

	public void setRecipientUserId(int recipientUserId) {
		this.recipientUserId = recipientUserId;
	}

}