package com.aeoncredit.aeonpay.core.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

/**
 * The persistent class for the merchant_accounts database table.
 * 
 */
@Entity
@Table(name="merchant_accounts")
@NamedQuery(name="MerchantAccount.findAll", query="SELECT m FROM MerchantAccount m")
public class MerchantAccount implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="merchant_account_id")
	private int merchantAccountId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="create_date")
	private Date createDate;

	@Column(name="create_user")
	private String createUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="delete_date")
	private Date deleteDate;

	@Column(name="delete_user")
	private String deleteUser;

	@Column(name="merchant_account")
	private String merchantAccount;

	//bi-directional many-to-one association to MerchantProfile
	@ManyToOne
	@JoinColumn(name="merchant_id")
	private MerchantProfile merchantProfile;

	//bi-directional many-to-one association to MerchantDevice
	@OneToMany(mappedBy="merchantAccount")
	private List<MerchantDevice> merchantDevices;

	public MerchantAccount() {
	}

	public int getMerchantAccountId() {
		return this.merchantAccountId;
	}

	public void setMerchantAccountId(int merchantAccountId) {
		this.merchantAccountId = merchantAccountId;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getDeleteDate() {
		return this.deleteDate;
	}

	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}

	public String getDeleteUser() {
		return this.deleteUser;
	}

	public void setDeleteUser(String deleteUser) {
		this.deleteUser = deleteUser;
	}

	public String getMerchantAccount() {
		return this.merchantAccount;
	}

	public void setMerchantAccount(String merchantAccount) {
		this.merchantAccount = merchantAccount;
	}

	public MerchantProfile getMerchantProfile() {
		return this.merchantProfile;
	}

	public void setMerchantProfile(MerchantProfile merchantProfile) {
		this.merchantProfile = merchantProfile;
	}

	public List<MerchantDevice> getMerchantDevices() {
		return this.merchantDevices;
	}

	public void setMerchantDevices(List<MerchantDevice> merchantDevices) {
		this.merchantDevices = merchantDevices;
	}

	public MerchantDevice addMerchantDevice(MerchantDevice merchantDevice) {
		getMerchantDevices().add(merchantDevice);
		merchantDevice.setMerchantAccount(this);

		return merchantDevice;
	}

	public MerchantDevice removeMerchantDevice(MerchantDevice merchantDevice) {
		getMerchantDevices().remove(merchantDevice);
		merchantDevice.setMerchantAccount(null);

		return merchantDevice;
	}

}