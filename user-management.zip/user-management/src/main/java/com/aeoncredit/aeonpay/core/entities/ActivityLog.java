package com.aeoncredit.aeonpay.core.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

/**
 * The persistent class for the activity_logs database table.
 * 
 */
@Entity
@Table(name="activity_logs")
@NamedQuery(name="ActivityLog.findAll", query="SELECT a FROM ActivityLog a")
public class ActivityLog implements Serializable {
	private static final long serialVersionUID = 1L;

	private String activity;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="activity_date")
	private Date activityDate;

	@Column(name="device_serial_code")
	private String deviceSerialCode;

	@Column(name="ip_address")
	private String ipAddress;

	private String module;

	@Column(name="profile_id")
	private String profileId;

	@Column(name="role_id")
	private String roleId;

	@Column(name="user_agent")
	private String userAgent;

	@Column(name="user_id")
	private int userId;

	public ActivityLog() {
	}

	public String getActivity() {
		return this.activity;
	}

	public void setActivity(String activity) {
		this.activity = activity;
	}

	public Date getActivityDate() {
		return this.activityDate;
	}

	public void setActivityDate(Date activityDate) {
		this.activityDate = activityDate;
	}

	public String getDeviceSerialCode() {
		return this.deviceSerialCode;
	}

	public void setDeviceSerialCode(String deviceSerialCode) {
		this.deviceSerialCode = deviceSerialCode;
	}

	public String getIpAddress() {
		return this.ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getModule() {
		return this.module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getProfileId() {
		return this.profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public String getRoleId() {
		return this.roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getUserAgent() {
		return this.userAgent;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

}