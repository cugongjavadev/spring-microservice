package com.aeoncredit.aeonpay.core.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the merchant_devices database table.
 * 
 */
@Entity
@Table(name="merchant_devices")
@NamedQuery(name="MerchantDevice.findAll", query="SELECT m FROM MerchantDevice m")
public class MerchantDevice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="device_id")
	private int deviceId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="create_date")
	private Date createDate;

	@Column(name="create_user")
	private String createUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="delete_date")
	private Date deleteDate;

	@Column(name="delete_user")
	private String deleteUser;

	@Column(name="device_serial_code")
	private String deviceSerialCode;

	@Column(name="device_status")
	private String deviceStatus;

	@Column(name="last_access_ip")
	private String lastAccessIp;

	@Column(name="last_access_time")
	private Timestamp lastAccessTime;

	@Column(name="last_access_user")
	private String lastAccessUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="update_date")
	private Date updateDate;

	@Column(name="update_user")
	private String updateUser;

	//bi-directional many-to-one association to MerchantAccount
	@ManyToOne
	@JoinColumn(name="merchant_account_id")
	private MerchantAccount merchantAccount;

	public MerchantDevice() {
	}

	public int getDeviceId() {
		return this.deviceId;
	}

	public void setDeviceId(int deviceId) {
		this.deviceId = deviceId;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public Date getDeleteDate() {
		return this.deleteDate;
	}

	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}

	public String getDeleteUser() {
		return this.deleteUser;
	}

	public void setDeleteUser(String deleteUser) {
		this.deleteUser = deleteUser;
	}

	public String getDeviceSerialCode() {
		return this.deviceSerialCode;
	}

	public void setDeviceSerialCode(String deviceSerialCode) {
		this.deviceSerialCode = deviceSerialCode;
	}

	public String getDeviceStatus() {
		return this.deviceStatus;
	}

	public void setDeviceStatus(String deviceStatus) {
		this.deviceStatus = deviceStatus;
	}

	public String getLastAccessIp() {
		return this.lastAccessIp;
	}

	public void setLastAccessIp(String lastAccessIp) {
		this.lastAccessIp = lastAccessIp;
	}

	public Timestamp getLastAccessTime() {
		return this.lastAccessTime;
	}

	public void setLastAccessTime(Timestamp lastAccessTime) {
		this.lastAccessTime = lastAccessTime;
	}

	public String getLastAccessUser() {
		return this.lastAccessUser;
	}

	public void setLastAccessUser(String lastAccessUser) {
		this.lastAccessUser = lastAccessUser;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateUser() {
		return this.updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public MerchantAccount getMerchantAccount() {
		return this.merchantAccount;
	}

	public void setMerchantAccount(MerchantAccount merchantAccount) {
		this.merchantAccount = merchantAccount;
	}

}