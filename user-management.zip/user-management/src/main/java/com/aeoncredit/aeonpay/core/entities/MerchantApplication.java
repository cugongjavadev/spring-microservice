package com.aeoncredit.aeonpay.core.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

/**
 * The persistent class for the merchant_applications database table.
 * 
 */
@Entity
@Table(name="merchant_applications")
@NamedQuery(name="MerchantApplication.findAll", query="SELECT m FROM MerchantApplication m")
public class MerchantApplication implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="application_id")
	private int applicationId;

	@Column(name="address_line1")
	private String addressLine1;

	@Column(name="address_line2")
	private String addressLine2;

	@Column(name="application_status")
	private byte applicationStatus;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="approve_date")
	private Date approveDate;

	@Column(name="approve_user")
	private String approveUser;

	@Column(name="business_name")
	private String businessName;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="business_registration_date")
	private Date businessRegistrationDate;

	@Column(name="business_registration_number")
	private String businessRegistrationNumber;

	private String city;

	@Column(name="contact_person")
	private String contactPerson;

	private String country;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="create_date")
	private Date createDate;

	@Column(name="create_user")
	private String createUser;

	private String email;

	@Column(name="fax_number")
	private String faxNumber;

	@Column(name="mobile_phone")
	private String mobilePhone;

	@Column(name="parent_merchant_id")
	private String parentMerchantId;

	@Column(name="phone_number")
	private String phoneNumber;

	@Column(name="post_code")
	private String postCode;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="receive_date")
	private Date receiveDate;

	@Column(name="receive_user")
	private String receiveUser;

	@Column(name="reference_number")
	private String referenceNumber;

	private String state;

	@Column(name="trading_name")
	private String tradingName;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="update_date")
	private Date updateDate;

	@Column(name="update_user")
	private String updateUser;

	//bi-directional many-to-one association to MerchantApplicationDocument
	@OneToMany(mappedBy="merchantApplication")
	private List<MerchantApplicationDocument> merchantApplicationDocuments;

	//bi-directional many-to-one association to MerchantProfile
	@OneToMany(mappedBy="merchantApplication")
	private List<MerchantProfile> merchantProfiles;

	public MerchantApplication() {
	}

	public int getApplicationId() {
		return this.applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public String getAddressLine1() {
		return this.addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return this.addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public byte getApplicationStatus() {
		return this.applicationStatus;
	}

	public void setApplicationStatus(byte applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public Date getApproveDate() {
		return this.approveDate;
	}

	public void setApproveDate(Date approveDate) {
		this.approveDate = approveDate;
	}

	public String getApproveUser() {
		return this.approveUser;
	}

	public void setApproveUser(String approveUser) {
		this.approveUser = approveUser;
	}

	public String getBusinessName() {
		return this.businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public Date getBusinessRegistrationDate() {
		return this.businessRegistrationDate;
	}

	public void setBusinessRegistrationDate(Date businessRegistrationDate) {
		this.businessRegistrationDate = businessRegistrationDate;
	}

	public String getBusinessRegistrationNumber() {
		return this.businessRegistrationNumber;
	}

	public void setBusinessRegistrationNumber(String businessRegistrationNumber) {
		this.businessRegistrationNumber = businessRegistrationNumber;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getContactPerson() {
		return this.contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFaxNumber() {
		return this.faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getMobilePhone() {
		return this.mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public String getParentMerchantId() {
		return this.parentMerchantId;
	}

	public void setParentMerchantId(String parentMerchantId) {
		this.parentMerchantId = parentMerchantId;
	}

	public String getPhoneNumber() {
		return this.phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPostCode() {
		return this.postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public Date getReceiveDate() {
		return this.receiveDate;
	}

	public void setReceiveDate(Date receiveDate) {
		this.receiveDate = receiveDate;
	}

	public String getReceiveUser() {
		return this.receiveUser;
	}

	public void setReceiveUser(String receiveUser) {
		this.receiveUser = receiveUser;
	}

	public String getReferenceNumber() {
		return this.referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getTradingName() {
		return this.tradingName;
	}

	public void setTradingName(String tradingName) {
		this.tradingName = tradingName;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateUser() {
		return this.updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public List<MerchantApplicationDocument> getMerchantApplicationDocuments() {
		return this.merchantApplicationDocuments;
	}

	public void setMerchantApplicationDocuments(List<MerchantApplicationDocument> merchantApplicationDocuments) {
		this.merchantApplicationDocuments = merchantApplicationDocuments;
	}

	public MerchantApplicationDocument addMerchantApplicationDocument(MerchantApplicationDocument merchantApplicationDocument) {
		getMerchantApplicationDocuments().add(merchantApplicationDocument);
		merchantApplicationDocument.setMerchantApplication(this);

		return merchantApplicationDocument;
	}

	public MerchantApplicationDocument removeMerchantApplicationDocument(MerchantApplicationDocument merchantApplicationDocument) {
		getMerchantApplicationDocuments().remove(merchantApplicationDocument);
		merchantApplicationDocument.setMerchantApplication(null);

		return merchantApplicationDocument;
	}

	public List<MerchantProfile> getMerchantProfiles() {
		return this.merchantProfiles;
	}

	public void setMerchantProfiles(List<MerchantProfile> merchantProfiles) {
		this.merchantProfiles = merchantProfiles;
	}

	public MerchantProfile addMerchantProfile(MerchantProfile merchantProfile) {
		getMerchantProfiles().add(merchantProfile);
		merchantProfile.setMerchantApplication(this);

		return merchantProfile;
	}

	public MerchantProfile removeMerchantProfile(MerchantProfile merchantProfile) {
		getMerchantProfiles().remove(merchantProfile);
		merchantProfile.setMerchantApplication(null);

		return merchantProfile;
	}

}