package com.aeoncredit.aeonpay.core.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the users database table.
 * 
 */
@Entity
@Table(name="users")
@NamedQuery(name="User.findAll", query="SELECT u FROM User u")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="user_id")
	private int userId;

	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;

	private String createdBy;

	private byte credentialsexpired;

	@Column(name="delete_user")
	private String deleteUser;

	private byte enabled;

	private byte expired;

	private byte locked;

	private String password;

	@Column(name="profile_id")
	private byte profileId;

	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedAt;

	private String updatedBy;

	private String username;

	private int version;

	//bi-directional one-to-one association to AdminProfile
	@OneToOne(mappedBy="user")
	private AdminProfile adminProfile;

	//bi-directional many-to-one association to ConsumerAccount
	@OneToMany(mappedBy="user")
	private List<ConsumerAccount> consumerAccounts;

	//bi-directional one-to-one association to CustomerProfile
	@OneToOne(mappedBy="user")
	private CustomerProfile customerProfile;

	//bi-directional many-to-one association to MerchantUser
	@OneToMany(mappedBy="user")
	private List<MerchantUser> merchantUsers;

	//bi-directional many-to-one association to UserCredential
	@OneToMany(mappedBy="user")
	private List<UserCredential> userCredentials;

	//bi-directional many-to-one association to UserRole
	@OneToMany(mappedBy="user")
	private List<UserRole> userRoles;

	public User() {
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public byte getCredentialsexpired() {
		return this.credentialsexpired;
	}

	public void setCredentialsexpired(byte credentialsexpired) {
		this.credentialsexpired = credentialsexpired;
	}

	public String getDeleteUser() {
		return this.deleteUser;
	}

	public void setDeleteUser(String deleteUser) {
		this.deleteUser = deleteUser;
	}

	public byte getEnabled() {
		return this.enabled;
	}

	public void setEnabled(byte enabled) {
		this.enabled = enabled;
	}

	public byte getExpired() {
		return this.expired;
	}

	public void setExpired(byte expired) {
		this.expired = expired;
	}

	public byte getLocked() {
		return this.locked;
	}

	public void setLocked(byte locked) {
		this.locked = locked;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public byte getProfileId() {
		return this.profileId;
	}

	public void setProfileId(byte profileId) {
		this.profileId = profileId;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getVersion() {
		return this.version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public AdminProfile getAdminProfile() {
		return this.adminProfile;
	}

	public void setAdminProfile(AdminProfile adminProfile) {
		this.adminProfile = adminProfile;
	}

	public List<ConsumerAccount> getConsumerAccounts() {
		return this.consumerAccounts;
	}

	public void setConsumerAccounts(List<ConsumerAccount> consumerAccounts) {
		this.consumerAccounts = consumerAccounts;
	}

	public ConsumerAccount addConsumerAccount(ConsumerAccount consumerAccount) {
		getConsumerAccounts().add(consumerAccount);
		consumerAccount.setUser(this);

		return consumerAccount;
	}

	public ConsumerAccount removeConsumerAccount(ConsumerAccount consumerAccount) {
		getConsumerAccounts().remove(consumerAccount);
		consumerAccount.setUser(null);

		return consumerAccount;
	}

	public CustomerProfile getCustomerProfile() {
		return this.customerProfile;
	}

	public void setCustomerProfile(CustomerProfile customerProfile) {
		this.customerProfile = customerProfile;
	}

	public List<MerchantUser> getMerchantUsers() {
		return this.merchantUsers;
	}

	public void setMerchantUsers(List<MerchantUser> merchantUsers) {
		this.merchantUsers = merchantUsers;
	}

	public MerchantUser addMerchantUser(MerchantUser merchantUser) {
		getMerchantUsers().add(merchantUser);
		merchantUser.setUser(this);

		return merchantUser;
	}

	public MerchantUser removeMerchantUser(MerchantUser merchantUser) {
		getMerchantUsers().remove(merchantUser);
		merchantUser.setUser(null);

		return merchantUser;
	}

	public List<UserCredential> getUserCredentials() {
		return this.userCredentials;
	}

	public void setUserCredentials(List<UserCredential> userCredentials) {
		this.userCredentials = userCredentials;
	}

	public UserCredential addUserCredential(UserCredential userCredential) {
		getUserCredentials().add(userCredential);
		userCredential.setUser(this);

		return userCredential;
	}

	public UserCredential removeUserCredential(UserCredential userCredential) {
		getUserCredentials().remove(userCredential);
		userCredential.setUser(null);

		return userCredential;
	}

	public List<UserRole> getUserRoles() {
		return this.userRoles;
	}

	public void setUserRoles(List<UserRole> userRoles) {
		this.userRoles = userRoles;
	}

	public UserRole addUserRole(UserRole userRole) {
		getUserRoles().add(userRole);
		userRole.setUser(this);

		return userRole;
	}

	public UserRole removeUserRole(UserRole userRole) {
		getUserRoles().remove(userRole);
		userRole.setUser(null);

		return userRole;
	}

}