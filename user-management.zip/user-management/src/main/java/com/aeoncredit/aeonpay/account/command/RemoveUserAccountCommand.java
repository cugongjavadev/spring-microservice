package com.aeoncredit.aeonpay.account.command;

import lombok.Value;

import org.axonframework.commandhandling.TargetAggregateIdentifier;

import javax.validation.constraints.Min;

@Value
public class RemoveUserAccountCommand {

    @TargetAggregateIdentifier
    private String userId;
    
    private String userName;
	
}
