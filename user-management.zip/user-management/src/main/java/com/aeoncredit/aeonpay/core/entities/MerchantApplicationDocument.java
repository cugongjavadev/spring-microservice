package com.aeoncredit.aeonpay.core.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

/**
 * The persistent class for the merchant_application_documents database table.
 * 
 */
@Entity
@Table(name="merchant_application_documents")
@NamedQuery(name="MerchantApplicationDocument.findAll", query="SELECT m FROM MerchantApplicationDocument m")
public class MerchantApplicationDocument implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="document_id")
	private int documentId;

	private String description;

	@Column(name="document_name")
	private String documentName;

	@Column(name="document_path")
	private String documentPath;

	@Column(name="document_thumbnail_path")
	private String documentThumbnailPath;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="upload_date")
	private Date uploadDate;

	@Column(name="upload_user")
	private String uploadUser;

	//bi-directional many-to-one association to MerchantApplication
	@ManyToOne
	@JoinColumn(name="application_id")
	private MerchantApplication merchantApplication;

	public MerchantApplicationDocument() {
	}

	public int getDocumentId() {
		return this.documentId;
	}

	public void setDocumentId(int documentId) {
		this.documentId = documentId;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDocumentName() {
		return this.documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentPath() {
		return this.documentPath;
	}

	public void setDocumentPath(String documentPath) {
		this.documentPath = documentPath;
	}

	public String getDocumentThumbnailPath() {
		return this.documentThumbnailPath;
	}

	public void setDocumentThumbnailPath(String documentThumbnailPath) {
		this.documentThumbnailPath = documentThumbnailPath;
	}

	public Date getUploadDate() {
		return this.uploadDate;
	}

	public void setUploadDate(Date uploadDate) {
		this.uploadDate = uploadDate;
	}

	public String getUploadUser() {
		return this.uploadUser;
	}

	public void setUploadUser(String uploadUser) {
		this.uploadUser = uploadUser;
	}

	public MerchantApplication getMerchantApplication() {
		return this.merchantApplication;
	}

	public void setMerchantApplication(MerchantApplication merchantApplication) {
		this.merchantApplication = merchantApplication;
	}

}