package com.aeoncredit.aeonpay.account.command;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.commandhandling.model.AggregateIdentifier;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.spring.stereotype.Aggregate;

import com.aeoncredit.aeonpay.account.event.UserAddedEvent;
import com.aeoncredit.aeonpay.account.event.UserDeletedEvent;

import static org.axonframework.commandhandling.model.AggregateLifecycle.apply;

@Aggregate
public class UserAccount {

    @AggregateIdentifier
    private String id;

    @SuppressWarnings("unused")
    private UserAccount() {
    }

    @CommandHandler
    public void addUser(String userid) {        
        apply(new UserAddedEvent(id, userid));
        System.out.println("Command --> addUser = " + userid);
    }
    
    @CommandHandler
    public void deleteUser(String userid) {        
        apply(new UserDeletedEvent(id, userid));
        System.out.println("Command --> deleteUser = " + userid);
    }

    @EventSourcingHandler
    public void on(UserAddedEvent event) {
        //this.id = event.getId();
        System.out.println("Event --> UserAddedEvent id : " + this.id);
    }

    @EventSourcingHandler
    public void on(UserDeletedEvent event) {
    	this.id = event.getUserId();
    	System.out.println("Event --> UserDeletedEvent id : " + this.id);
    }
}
