package com.aeoncredit.aeonpay.account.event;

import lombok.Value;

@Value
public class UserAddedEvent {
	
    private String userId;
    
    private String userName;
    
    public UserAddedEvent(String userId, String userName) {
    	this.userId = userId;
    	this.userName = userName;
    }
}
