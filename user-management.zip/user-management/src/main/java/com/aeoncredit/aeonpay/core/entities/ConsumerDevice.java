package com.aeoncredit.aeonpay.core.entities;

import java.io.Serializable;
import java.util.Date;
import java.sql.Timestamp;

import javax.persistence.*;

/**
 * The persistent class for the consumer_devices database table.
 * 
 */
@Entity
@Table(name="consumer_devices")
@NamedQuery(name="ConsumerDevice.findAll", query="SELECT c FROM ConsumerDevice c")
public class ConsumerDevice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="user_id")
	private int userId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="create_date")
	private Date createDate;

	@Column(name="create_user")
	private String createUser;

	@Column(name="device_serial_code")
	private String deviceSerialCode;

	@Column(name="device_status")
	private byte deviceStatus;

	@Column(name="last_access_ip")
	private String lastAccessIp;

	@Column(name="last_access_time")
	private Timestamp lastAccessTime;

	@Column(name="last_access_user")
	private String lastAccessUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="update_date")
	private Date updateDate;

	@Column(name="update_user")
	private String updateUser;

	public ConsumerDevice() {
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getDeviceSerialCode() {
		return this.deviceSerialCode;
	}

	public void setDeviceSerialCode(String deviceSerialCode) {
		this.deviceSerialCode = deviceSerialCode;
	}

	public byte getDeviceStatus() {
		return this.deviceStatus;
	}

	public void setDeviceStatus(byte deviceStatus) {
		this.deviceStatus = deviceStatus;
	}

	public String getLastAccessIp() {
		return this.lastAccessIp;
	}

	public void setLastAccessIp(String lastAccessIp) {
		this.lastAccessIp = lastAccessIp;
	}

	public Timestamp getLastAccessTime() {
		return this.lastAccessTime;
	}

	public void setLastAccessTime(Timestamp lastAccessTime) {
		this.lastAccessTime = lastAccessTime;
	}

	public String getLastAccessUser() {
		return this.lastAccessUser;
	}

	public void setLastAccessUser(String lastAccessUser) {
		this.lastAccessUser = lastAccessUser;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateUser() {
		return this.updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

}