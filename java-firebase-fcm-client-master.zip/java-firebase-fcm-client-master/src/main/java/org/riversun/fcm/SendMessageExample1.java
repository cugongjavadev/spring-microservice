package org.riversun.fcm;

import org.riversun.fcm.model.EntityMessage;
import org.riversun.fcm.model.FcmResponse;

public class SendMessageExample1 {
	public static void main(String[] args) {

		FcmClient client = new FcmClient();
		// You can get from firebase console.
		// "select your project>project settings>cloud messaging"
		client.setAPIKey("AAAAb64kbFA:APA91bGlPyJPuge7kh2ZOnPE8HiWy9V44PLg_8fXoJ0fAlJAcf6_-rHiM6ANgxZTXnqDs6MyP2y2Yn9g1luG7-zCz2Cqv94nLc5mKYnPf8cLSVB2keZQ3KsPilOnd_LG3gFfB8sHl55i");

		// Data model for sending messages to specific entity(mobile devices,browser front-end apps)s
		EntityMessage msg = new EntityMessage();

		// Set registration token that can be retrieved
		// from Android entity(mobile devices,browser front-end apps) when calling
		// FirebaseInstanceId.getInstance().getToken();
		msg.addRegistrationToken("cye2DAbEpUY:APA91bFuLssH4G4cWGhCS4BauHtUIVcqEoggUJQuBFbFKnjjcgI0EZTouZJAS7_Y1UpCxJ1cHD9NBcFhOIcQGQwDas1PuHRw9yVE7Sqb7c_rptgtgEyIWtWqt7bj--FPlIWRUv-I_zLt");

		// Add key value pair into payload
		msg.putStringData("myKey1", "myValue1-->XXXX");
		msg.putStringData("myKey2", "myValue2CHRISdebug");

		// push
		FcmResponse res = client.pushToEntities(msg);

		System.out.println(res);

	}
}
