package com.aeoncredit.aeonpay;

import android.content.BroadcastReceiver;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.TextView;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

public class MainActivity extends AppCompatActivity {

    MyReceiver myReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        //Log the token
        System.err.println("<CHRIS DEBUG>----->Refreshed token: " + refreshedToken);

        setContentView(R.layout.activity_main);
        EditText notifytext = (EditText) findViewById(R.id.token);
        notifytext.setText(refreshedToken);
    }

    @Override
    protected void onStart() {
        // TODO Auto-generated method stub

        //Register BroadcastReceiver
        //to receive event from our service
        myReceiver = new MyReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(MyAndroidFirebaseMsgService.MY_ACTION);
        registerReceiver(myReceiver, intentFilter);

       // Intent intent = new Intent(MainActivity.this,
       //         com.aeoncredit.aeonpay.MyAndroidFirebaseMsgService.class);
       // startService(intent);

        super.onStart();
    }

    private class MyReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context arg0, Intent arg1) {
            // TODO Auto-generated method stub

            System.err.println("-----> HERE");

            String datapassed = arg1.getStringExtra("DATAPASSED");

            EditText messg = (EditText) findViewById(R.id.message);
            messg.setText(String.valueOf(datapassed));

        }

    }
}